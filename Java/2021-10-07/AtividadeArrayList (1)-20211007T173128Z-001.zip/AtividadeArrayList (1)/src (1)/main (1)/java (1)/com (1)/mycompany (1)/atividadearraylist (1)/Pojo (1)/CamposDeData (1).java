package com.mycompany.atividadearraylist.Pojo;

import java.util.*;

public abstract class CamposDeData{
    
    protected Date dataInsert;
    
    public Date getDataInsert(){
        return dataInsert;
    }
    
    public void setDataInsert(Date dataInsert){
        this.dataInsert = dataInsert;
    }
}

    
    

